/*
 * MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.zehirmoduforge.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fluids.FluidType;

import net.mcreator.zehirmoduforge.fluid.types.AsidKovasiFluidType;
import net.mcreator.zehirmoduforge.ZehirmoduforgeMod;

public class ZehirmoduforgeModFluidTypes {
	public static final DeferredRegister<FluidType> REGISTRY = DeferredRegister.create(ForgeRegistries.Keys.FLUID_TYPES, ZehirmoduforgeMod.MODID);
	public static final RegistryObject<FluidType> ASID_KOVASI_TYPE = REGISTRY.register("asid_kovasi", AsidKovasiFluidType::new);
}