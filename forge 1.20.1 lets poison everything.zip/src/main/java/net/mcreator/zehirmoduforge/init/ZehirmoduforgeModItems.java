/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.zehirmoduforge.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.zehirmoduforge.item.*;
import net.mcreator.zehirmoduforge.ZehirmoduforgeMod;

public class ZehirmoduforgeModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, ZehirmoduforgeMod.MODID);
	public static final RegistryObject<Item> ZEHIR_MADENI;
	public static final RegistryObject<Item> ZEHIR_CEVHERI;
	public static final RegistryObject<Item> ASID_KOVASI_BUCKET;
	public static final RegistryObject<Item> EKMEK;
	public static final RegistryObject<Item> BIFTEK;
	public static final RegistryObject<Item> PISMIS_PATATES;
	public static final RegistryObject<Item> NAKARAT_MEYVESI;
	public static final RegistryObject<Item> ALTIN_ELMA;
	public static final RegistryObject<Item> PISMIS_DOMUZ_PIRZOLASI;
	public static final RegistryObject<Item> PISMIS_KOYUN_ETI;
	public static final RegistryObject<Item> PISMIS_TAVUK_ETI;
	public static final RegistryObject<Item> PISMIS_TAVSANETI;
	public static final RegistryObject<Item> PISMIS_MORINA;
	public static final RegistryObject<Item> PISMIS_SOMON;
	public static final RegistryObject<Item> KURABIYE;
	public static final RegistryObject<Item> BAL_KABAGI_TURTASI;
	public static final RegistryObject<Item> SUT_KOVASI;
	public static final RegistryObject<Item> BAL_SISESI;
	public static final RegistryObject<Item> KURUTULMUS_SU_YOSUNU;
	public static final RegistryObject<Item> ELMA;
	public static final RegistryObject<Item> MANTAR_GUVECI;
	public static final RegistryObject<Item> PANCAR_CORBASI;
	public static final RegistryObject<Item> TAVSAN_GUVECI;
	public static final RegistryObject<Item> SUPHELI_GUVEC;
	public static final RegistryObject<Item> ZEHIRLI_TAS;
	public static final RegistryObject<Item> KIRIKTAS;
	public static final RegistryObject<Item> MESE_TAHTASI;
	public static final RegistryObject<Item> ZEHIR_DEDEKTORU;
	public static final RegistryObject<Item> MESE_KUTUGU;
	public static final RegistryObject<Item> GLASS;
	public static final RegistryObject<Item> LADIN_KUTUGU;
	public static final RegistryObject<Item> LADIN_TAHTASI;
	public static final RegistryObject<Item> HUS_KUTUGU;
	public static final RegistryObject<Item> HUS_TAHTASI;
	public static final RegistryObject<Item> ORMAN_AGACI_KUTUGU;
	public static final RegistryObject<Item> ORMAN_AGACI_TAHTASI;
	public static final RegistryObject<Item> TOPRAK;
	public static final RegistryObject<Item> AKASYA_KUTUGU;
	public static final RegistryObject<Item> AKASYA_TAHTASI;
	public static final RegistryObject<Item> KOYU_MESE_KUTUGU;
	public static final RegistryObject<Item> KOYU_MESE_TAHTASI;
	public static final RegistryObject<Item> MANGROVKUTUGU;
	public static final RegistryObject<Item> MANGROVTAHTASI;
	public static final RegistryObject<Item> KIRAZ_AGACI_KUTUGU;
	public static final RegistryObject<Item> KIRAZ_AGACI_TAHTA;
	public static final RegistryObject<Item> PANZEHIR;
	static {
		ZEHIR_MADENI = block(ZehirmoduforgeModBlocks.ZEHIR_MADENI);
		ZEHIR_CEVHERI = REGISTRY.register("zehir_cevheri", ZehirCevheriItem::new);
		ASID_KOVASI_BUCKET = REGISTRY.register("asid_kovasi_bucket", AsidKovasiItem::new);
		EKMEK = REGISTRY.register("ekmek", EkmekItem::new);
		BIFTEK = REGISTRY.register("biftek", BiftekItem::new);
		PISMIS_PATATES = REGISTRY.register("pismis_patates", PismisPatatesItem::new);
		NAKARAT_MEYVESI = REGISTRY.register("nakarat_meyvesi", NakaratMeyvesiItem::new);
		ALTIN_ELMA = REGISTRY.register("altin_elma", AltinElmaItem::new);
		PISMIS_DOMUZ_PIRZOLASI = REGISTRY.register("pismis_domuz_pirzolasi", PismisDomuzPirzolasiItem::new);
		PISMIS_KOYUN_ETI = REGISTRY.register("pismis_koyun_eti", PismisKoyunEtiItem::new);
		PISMIS_TAVUK_ETI = REGISTRY.register("pismis_tavuk_eti", PismisTavukEtiItem::new);
		PISMIS_TAVSANETI = REGISTRY.register("pismis_tavsaneti", PismisTavsanetiItem::new);
		PISMIS_MORINA = REGISTRY.register("pismis_morina", PismisMorinaItem::new);
		PISMIS_SOMON = REGISTRY.register("pismis_somon", PismisSomonItem::new);
		KURABIYE = REGISTRY.register("kurabiye", KurabiyeItem::new);
		BAL_KABAGI_TURTASI = REGISTRY.register("bal_kabagi_turtasi", BalKabagiTurtasiItem::new);
		SUT_KOVASI = REGISTRY.register("sut_kovasi", SutKovasiItem::new);
		BAL_SISESI = REGISTRY.register("bal_sisesi", BalSisesiItem::new);
		KURUTULMUS_SU_YOSUNU = REGISTRY.register("kurutulmus_su_yosunu", KurutulmusSuYosunuItem::new);
		ELMA = REGISTRY.register("elma", ElmaItem::new);
		MANTAR_GUVECI = REGISTRY.register("mantar_guveci", MantarGuveciItem::new);
		PANCAR_CORBASI = REGISTRY.register("pancar_corbasi", PancarCorbasiItem::new);
		TAVSAN_GUVECI = REGISTRY.register("tavsan_guveci", TavsanGuveciItem::new);
		SUPHELI_GUVEC = REGISTRY.register("supheli_guvec", SupheliGuvecItem::new);
		ZEHIRLI_TAS = block(ZehirmoduforgeModBlocks.ZEHIRLI_TAS);
		KIRIKTAS = block(ZehirmoduforgeModBlocks.KIRIKTAS);
		MESE_TAHTASI = block(ZehirmoduforgeModBlocks.MESE_TAHTASI);
		ZEHIR_DEDEKTORU = REGISTRY.register("zehir_dedektoru", ZehirDedektoruItem::new);
		MESE_KUTUGU = block(ZehirmoduforgeModBlocks.MESE_KUTUGU);
		GLASS = block(ZehirmoduforgeModBlocks.GLASS);
		LADIN_KUTUGU = block(ZehirmoduforgeModBlocks.LADIN_KUTUGU);
		LADIN_TAHTASI = block(ZehirmoduforgeModBlocks.LADIN_TAHTASI);
		HUS_KUTUGU = block(ZehirmoduforgeModBlocks.HUS_KUTUGU);
		HUS_TAHTASI = block(ZehirmoduforgeModBlocks.HUS_TAHTASI);
		ORMAN_AGACI_KUTUGU = block(ZehirmoduforgeModBlocks.ORMAN_AGACI_KUTUGU);
		ORMAN_AGACI_TAHTASI = block(ZehirmoduforgeModBlocks.ORMAN_AGACI_TAHTASI);
		TOPRAK = block(ZehirmoduforgeModBlocks.TOPRAK);
		AKASYA_KUTUGU = block(ZehirmoduforgeModBlocks.AKASYA_KUTUGU);
		AKASYA_TAHTASI = block(ZehirmoduforgeModBlocks.AKASYA_TAHTASI);
		KOYU_MESE_KUTUGU = block(ZehirmoduforgeModBlocks.KOYU_MESE_KUTUGU);
		KOYU_MESE_TAHTASI = block(ZehirmoduforgeModBlocks.KOYU_MESE_TAHTASI);
		MANGROVKUTUGU = block(ZehirmoduforgeModBlocks.MANGROVKUTUGU);
		MANGROVTAHTASI = block(ZehirmoduforgeModBlocks.MANGROVTAHTASI);
		KIRAZ_AGACI_KUTUGU = block(ZehirmoduforgeModBlocks.KIRAZ_AGACI_KUTUGU);
		KIRAZ_AGACI_TAHTA = block(ZehirmoduforgeModBlocks.KIRAZ_AGACI_TAHTA);
		PANZEHIR = REGISTRY.register("panzehir", PanzehirItem::new);
	}

	// Start of user code block custom items
	// End of user code block custom items
	private static RegistryObject<Item> block(RegistryObject<Block> block) {
		return block(block, new Item.Properties());
	}

	private static RegistryObject<Item> block(RegistryObject<Block> block, Item.Properties properties) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), properties));
	}
}