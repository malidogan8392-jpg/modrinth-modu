/*
 * MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.zehirmoduforge.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.material.FlowingFluid;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.ItemBlockRenderTypes;

import net.mcreator.zehirmoduforge.fluid.AsidKovasiFluid;
import net.mcreator.zehirmoduforge.ZehirmoduforgeMod;

public class ZehirmoduforgeModFluids {
	public static final DeferredRegister<Fluid> REGISTRY = DeferredRegister.create(ForgeRegistries.FLUIDS, ZehirmoduforgeMod.MODID);
	public static final RegistryObject<FlowingFluid> ASID_KOVASI = REGISTRY.register("asid_kovasi", AsidKovasiFluid.Source::new);
	public static final RegistryObject<FlowingFluid> FLOWING_ASID_KOVASI = REGISTRY.register("flowing_asid_kovasi", AsidKovasiFluid.Flowing::new);

	@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
	public static class FluidsClientSideHandler {
		@SubscribeEvent
		public static void clientSetup(FMLClientSetupEvent event) {
			ItemBlockRenderTypes.setRenderLayer(ASID_KOVASI.get(), RenderType.translucent());
			ItemBlockRenderTypes.setRenderLayer(FLOWING_ASID_KOVASI.get(), RenderType.translucent());
		}
	}
}