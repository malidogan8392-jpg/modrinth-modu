/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.zehirmoduforge.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.effect.MobEffect;

import net.mcreator.zehirmoduforge.potion.ZehirVarMobEffect;
import net.mcreator.zehirmoduforge.ZehirmoduforgeMod;

public class ZehirmoduforgeModMobEffects {
	public static final DeferredRegister<MobEffect> REGISTRY = DeferredRegister.create(ForgeRegistries.MOB_EFFECTS, ZehirmoduforgeMod.MODID);
	public static final RegistryObject<MobEffect> ZEHIR_VAR = REGISTRY.register("zehir_var", ZehirVarMobEffect::new);
}