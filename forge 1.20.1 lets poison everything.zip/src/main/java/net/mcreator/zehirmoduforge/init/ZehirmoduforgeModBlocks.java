/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.zehirmoduforge.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

import net.mcreator.zehirmoduforge.block.*;
import net.mcreator.zehirmoduforge.ZehirmoduforgeMod;

public class ZehirmoduforgeModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, ZehirmoduforgeMod.MODID);
	public static final RegistryObject<Block> ZEHIR_MADENI;
	public static final RegistryObject<Block> ASID_KOVASI;
	public static final RegistryObject<Block> ZEHIRLI_TAS;
	public static final RegistryObject<Block> KIRIKTAS;
	public static final RegistryObject<Block> MESE_TAHTASI;
	public static final RegistryObject<Block> MESE_KUTUGU;
	public static final RegistryObject<Block> GLASS;
	public static final RegistryObject<Block> LADIN_KUTUGU;
	public static final RegistryObject<Block> LADIN_TAHTASI;
	public static final RegistryObject<Block> HUS_KUTUGU;
	public static final RegistryObject<Block> HUS_TAHTASI;
	public static final RegistryObject<Block> ORMAN_AGACI_KUTUGU;
	public static final RegistryObject<Block> ORMAN_AGACI_TAHTASI;
	public static final RegistryObject<Block> TOPRAK;
	public static final RegistryObject<Block> AKASYA_KUTUGU;
	public static final RegistryObject<Block> AKASYA_TAHTASI;
	public static final RegistryObject<Block> KOYU_MESE_KUTUGU;
	public static final RegistryObject<Block> KOYU_MESE_TAHTASI;
	public static final RegistryObject<Block> MANGROVKUTUGU;
	public static final RegistryObject<Block> MANGROVTAHTASI;
	public static final RegistryObject<Block> KIRAZ_AGACI_KUTUGU;
	public static final RegistryObject<Block> KIRAZ_AGACI_TAHTA;
	static {
		ZEHIR_MADENI = REGISTRY.register("zehir_madeni", ZehirMadeniBlock::new);
		ASID_KOVASI = REGISTRY.register("asid_kovasi", AsidKovasiBlock::new);
		ZEHIRLI_TAS = REGISTRY.register("zehirli_tas", ZehirliTasBlock::new);
		KIRIKTAS = REGISTRY.register("kiriktas", KiriktasBlock::new);
		MESE_TAHTASI = REGISTRY.register("mese_tahtasi", MeseTahtasiBlock::new);
		MESE_KUTUGU = REGISTRY.register("mese_kutugu", MeseKutuguBlock::new);
		GLASS = REGISTRY.register("glass", GlassBlock::new);
		LADIN_KUTUGU = REGISTRY.register("ladin_kutugu", LadinKutuguBlock::new);
		LADIN_TAHTASI = REGISTRY.register("ladin_tahtasi", LadinTahtasiBlock::new);
		HUS_KUTUGU = REGISTRY.register("hus_kutugu", HusKutuguBlock::new);
		HUS_TAHTASI = REGISTRY.register("hus_tahtasi", HusTahtasiBlock::new);
		ORMAN_AGACI_KUTUGU = REGISTRY.register("orman_agaci_kutugu", OrmanAgaciKutuguBlock::new);
		ORMAN_AGACI_TAHTASI = REGISTRY.register("orman_agaci_tahtasi", OrmanAgaciTahtasiBlock::new);
		TOPRAK = REGISTRY.register("toprak", ToprakBlock::new);
		AKASYA_KUTUGU = REGISTRY.register("akasya_kutugu", AkasyaKutuguBlock::new);
		AKASYA_TAHTASI = REGISTRY.register("akasya_tahtasi", AkasyaTahtasiBlock::new);
		KOYU_MESE_KUTUGU = REGISTRY.register("koyu_mese_kutugu", KoyuMeseKutuguBlock::new);
		KOYU_MESE_TAHTASI = REGISTRY.register("koyu_mese_tahtasi", KoyuMeseTahtasiBlock::new);
		MANGROVKUTUGU = REGISTRY.register("mangrovkutugu", MangrovkutuguBlock::new);
		MANGROVTAHTASI = REGISTRY.register("mangrovtahtasi", MangrovtahtasiBlock::new);
		KIRAZ_AGACI_KUTUGU = REGISTRY.register("kiraz_agaci_kutugu", KirazAgaciKutuguBlock::new);
		KIRAZ_AGACI_TAHTA = REGISTRY.register("kiraz_agaci_tahta", KirazAgaciTahtaBlock::new);
	}
	// Start of user code block custom blocks
	// End of user code block custom blocks
}