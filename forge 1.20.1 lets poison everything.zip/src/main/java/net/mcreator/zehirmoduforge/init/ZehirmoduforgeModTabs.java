/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.zehirmoduforge.init;

import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;

import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.core.registries.Registries;

import net.mcreator.zehirmoduforge.ZehirmoduforgeMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class ZehirmoduforgeModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, ZehirmoduforgeMod.MODID);

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.INGREDIENTS) {
			tabData.accept(ZehirmoduforgeModBlocks.ZEHIR_MADENI.get().asItem());
			tabData.accept(ZehirmoduforgeModItems.ZEHIR_CEVHERI.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.FOOD_AND_DRINKS) {
			tabData.accept(ZehirmoduforgeModItems.ASID_KOVASI_BUCKET.get());
			tabData.accept(ZehirmoduforgeModItems.EKMEK.get());
			tabData.accept(ZehirmoduforgeModItems.BIFTEK.get());
			tabData.accept(ZehirmoduforgeModItems.PISMIS_PATATES.get());
			tabData.accept(ZehirmoduforgeModItems.NAKARAT_MEYVESI.get());
			tabData.accept(ZehirmoduforgeModItems.ALTIN_ELMA.get());
			tabData.accept(ZehirmoduforgeModItems.PISMIS_DOMUZ_PIRZOLASI.get());
			tabData.accept(ZehirmoduforgeModItems.PISMIS_KOYUN_ETI.get());
			tabData.accept(ZehirmoduforgeModItems.PISMIS_TAVUK_ETI.get());
			tabData.accept(ZehirmoduforgeModItems.PISMIS_TAVSANETI.get());
			tabData.accept(ZehirmoduforgeModItems.PISMIS_MORINA.get());
			tabData.accept(ZehirmoduforgeModItems.PISMIS_SOMON.get());
			tabData.accept(ZehirmoduforgeModItems.KURABIYE.get());
			tabData.accept(ZehirmoduforgeModItems.BAL_KABAGI_TURTASI.get());
			tabData.accept(ZehirmoduforgeModItems.SUT_KOVASI.get());
			tabData.accept(ZehirmoduforgeModItems.BAL_SISESI.get());
			tabData.accept(ZehirmoduforgeModItems.KURUTULMUS_SU_YOSUNU.get());
			tabData.accept(ZehirmoduforgeModItems.ELMA.get());
			tabData.accept(ZehirmoduforgeModItems.MANTAR_GUVECI.get());
			tabData.accept(ZehirmoduforgeModItems.PANCAR_CORBASI.get());
			tabData.accept(ZehirmoduforgeModItems.TAVSAN_GUVECI.get());
			tabData.accept(ZehirmoduforgeModItems.SUPHELI_GUVEC.get());
			tabData.accept(ZehirmoduforgeModItems.PANZEHIR.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.BUILDING_BLOCKS) {
			tabData.accept(ZehirmoduforgeModBlocks.KIRIKTAS.get().asItem());
			tabData.accept(ZehirmoduforgeModBlocks.GLASS.get().asItem());
			tabData.accept(ZehirmoduforgeModBlocks.HUS_KUTUGU.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.REDSTONE_BLOCKS) {
			tabData.accept(ZehirmoduforgeModItems.ZEHIR_DEDEKTORU.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.NATURAL_BLOCKS) {
			tabData.accept(ZehirmoduforgeModBlocks.LADIN_KUTUGU.get().asItem());
		}
	}
}