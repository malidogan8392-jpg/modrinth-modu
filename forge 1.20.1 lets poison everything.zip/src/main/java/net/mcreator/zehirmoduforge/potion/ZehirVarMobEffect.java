package net.mcreator.zehirmoduforge.potion;

import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffect;

public class ZehirVarMobEffect extends MobEffect {
	public ZehirVarMobEffect() {
		super(MobEffectCategory.NEUTRAL, -52429);
	}

	@Override
	public boolean isDurationEffectTick(int duration, int amplifier) {
		return true;
	}
}