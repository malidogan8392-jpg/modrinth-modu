package net.mcreator.zehirmoduforge.item;

import net.minecraft.world.item.Item;

public class ZehirCevheriItem extends Item {
	public ZehirCevheriItem() {
		super(new Item.Properties());
	}
}