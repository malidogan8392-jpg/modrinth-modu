package net.mcreator.zehirmoduforge.fluid;

import net.minecraftforge.fluids.ForgeFlowingFluid;

import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.LiquidBlock;

import net.mcreator.zehirmoduforge.init.ZehirmoduforgeModItems;
import net.mcreator.zehirmoduforge.init.ZehirmoduforgeModFluids;
import net.mcreator.zehirmoduforge.init.ZehirmoduforgeModFluidTypes;
import net.mcreator.zehirmoduforge.init.ZehirmoduforgeModBlocks;

public abstract class AsidKovasiFluid extends ForgeFlowingFluid {
	public static final ForgeFlowingFluid.Properties PROPERTIES = new ForgeFlowingFluid.Properties(() -> ZehirmoduforgeModFluidTypes.ASID_KOVASI_TYPE.get(), () -> ZehirmoduforgeModFluids.ASID_KOVASI.get(),
			() -> ZehirmoduforgeModFluids.FLOWING_ASID_KOVASI.get()).explosionResistance(100f).bucket(() -> ZehirmoduforgeModItems.ASID_KOVASI_BUCKET.get()).block(() -> (LiquidBlock) ZehirmoduforgeModBlocks.ASID_KOVASI.get());

	private AsidKovasiFluid() {
		super(PROPERTIES);
	}

	public static class Source extends AsidKovasiFluid {
		public int getAmount(FluidState state) {
			return 8;
		}

		public boolean isSource(FluidState state) {
			return true;
		}
	}

	public static class Flowing extends AsidKovasiFluid {
		protected void createFluidStateDefinition(StateDefinition.Builder<Fluid, FluidState> builder) {
			super.createFluidStateDefinition(builder);
			builder.add(LEVEL);
		}

		public int getAmount(FluidState state) {
			return state.getValue(LEVEL);
		}

		public boolean isSource(FluidState state) {
			return false;
		}
	}
}