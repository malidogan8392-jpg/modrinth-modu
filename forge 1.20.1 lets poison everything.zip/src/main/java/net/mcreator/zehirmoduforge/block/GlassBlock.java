package net.mcreator.zehirmoduforge.block;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.Block;

public class GlassBlock extends Block {
	public GlassBlock() {
		super(BlockBehaviour.Properties.of().sound(SoundType.GLASS).strength(0.3f));
	}
}