package net.mcreator.zehirmoduforge.procedures;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.core.NonNullList;

import net.mcreator.zehirmoduforge.init.ZehirmoduforgeModMobEffects;
import net.mcreator.zehirmoduforge.init.ZehirmoduforgeModItems;
import net.mcreator.zehirmoduforge.init.ZehirmoduforgeModBlocks;

import java.util.List;

public class ZehirDedektoruItemInHandTickProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		if (hasEntityInInventory(entity, new ItemStack(ZehirmoduforgeModItems.EKMEK.get()))) {
			if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
				_entity.addEffect(new MobEffectInstance(ZehirmoduforgeModMobEffects.ZEHIR_VAR.get(), 60, 1));
		}
		if (hasEntityInInventory(entity, new ItemStack(ZehirmoduforgeModItems.BIFTEK.get()))) {
			if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
				_entity.addEffect(new MobEffectInstance(ZehirmoduforgeModMobEffects.ZEHIR_VAR.get(), 60, 1));
		}
		if (hasEntityInInventory(entity, new ItemStack(ZehirmoduforgeModItems.PISMIS_PATATES.get()))) {
			if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
				_entity.addEffect(new MobEffectInstance(ZehirmoduforgeModMobEffects.ZEHIR_VAR.get(), 60, 1));
		}
		if (hasEntityInInventory(entity, new ItemStack(ZehirmoduforgeModItems.NAKARAT_MEYVESI.get()))) {
			if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
				_entity.addEffect(new MobEffectInstance(ZehirmoduforgeModMobEffects.ZEHIR_VAR.get(), 60, 1));
		}
		if (hasEntityInInventory(entity, new ItemStack(ZehirmoduforgeModItems.ALTIN_ELMA.get()))) {
			if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
				_entity.addEffect(new MobEffectInstance(ZehirmoduforgeModMobEffects.ZEHIR_VAR.get(), 60, 1));
		}
		if (hasEntityInInventory(entity, new ItemStack(ZehirmoduforgeModItems.PISMIS_DOMUZ_PIRZOLASI.get()))) {
			if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
				_entity.addEffect(new MobEffectInstance(ZehirmoduforgeModMobEffects.ZEHIR_VAR.get(), 60, 1));
		}
		if (hasEntityInInventory(entity, new ItemStack(ZehirmoduforgeModItems.PISMIS_KOYUN_ETI.get()))) {
			if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
				_entity.addEffect(new MobEffectInstance(ZehirmoduforgeModMobEffects.ZEHIR_VAR.get(), 60, 1));
		}
		if (hasEntityInInventory(entity, new ItemStack(ZehirmoduforgeModItems.PISMIS_TAVUK_ETI.get()))) {
			if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
				_entity.addEffect(new MobEffectInstance(ZehirmoduforgeModMobEffects.ZEHIR_VAR.get(), 60, 1));
		}
		if (hasEntityInInventory(entity, new ItemStack(ZehirmoduforgeModItems.PISMIS_TAVSANETI.get()))) {
			if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
				_entity.addEffect(new MobEffectInstance(ZehirmoduforgeModMobEffects.ZEHIR_VAR.get(), 60, 1));
		}
		if (hasEntityInInventory(entity, new ItemStack(ZehirmoduforgeModItems.PISMIS_MORINA.get()))) {
			if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
				_entity.addEffect(new MobEffectInstance(ZehirmoduforgeModMobEffects.ZEHIR_VAR.get(), 60, 1));
		}
		if (hasEntityInInventory(entity, new ItemStack(ZehirmoduforgeModItems.PISMIS_SOMON.get()))) {
			if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
				_entity.addEffect(new MobEffectInstance(ZehirmoduforgeModMobEffects.ZEHIR_VAR.get(), 60, 1));
		}
		if (hasEntityInInventory(entity, new ItemStack(ZehirmoduforgeModItems.KURABIYE.get()))) {
			if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
				_entity.addEffect(new MobEffectInstance(ZehirmoduforgeModMobEffects.ZEHIR_VAR.get(), 60, 1));
		}
		if (hasEntityInInventory(entity, new ItemStack(ZehirmoduforgeModItems.BAL_KABAGI_TURTASI.get()))) {
			if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
				_entity.addEffect(new MobEffectInstance(ZehirmoduforgeModMobEffects.ZEHIR_VAR.get(), 60, 1));
		}
		if (hasEntityInInventory(entity, new ItemStack(ZehirmoduforgeModItems.SUT_KOVASI.get()))) {
			if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
				_entity.addEffect(new MobEffectInstance(ZehirmoduforgeModMobEffects.ZEHIR_VAR.get(), 60, 1));
		}
		if (hasEntityInInventory(entity, new ItemStack(ZehirmoduforgeModItems.BAL_SISESI.get()))) {
			if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
				_entity.addEffect(new MobEffectInstance(ZehirmoduforgeModMobEffects.ZEHIR_VAR.get(), 60, 1));
		}
		if (hasEntityInInventory(entity, new ItemStack(ZehirmoduforgeModItems.KURUTULMUS_SU_YOSUNU.get()))) {
			if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
				_entity.addEffect(new MobEffectInstance(ZehirmoduforgeModMobEffects.ZEHIR_VAR.get(), 60, 1));
		}
		if (hasEntityInInventory(entity, new ItemStack(ZehirmoduforgeModItems.ELMA.get()))) {
			if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
				_entity.addEffect(new MobEffectInstance(ZehirmoduforgeModMobEffects.ZEHIR_VAR.get(), 60, 1));
		}
		if (hasEntityInInventory(entity, new ItemStack(ZehirmoduforgeModItems.MANTAR_GUVECI.get()))) {
			if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
				_entity.addEffect(new MobEffectInstance(ZehirmoduforgeModMobEffects.ZEHIR_VAR.get(), 60, 1));
		}
		if (hasEntityInInventory(entity, new ItemStack(ZehirmoduforgeModItems.PANCAR_CORBASI.get()))) {
			if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
				_entity.addEffect(new MobEffectInstance(ZehirmoduforgeModMobEffects.ZEHIR_VAR.get(), 60, 1));
		}
		if (hasEntityInInventory(entity, new ItemStack(ZehirmoduforgeModItems.TAVSAN_GUVECI.get()))) {
			if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
				_entity.addEffect(new MobEffectInstance(ZehirmoduforgeModMobEffects.ZEHIR_VAR.get(), 60, 1));
		}
		if (hasEntityInInventory(entity, new ItemStack(ZehirmoduforgeModItems.SUPHELI_GUVEC.get()))) {
			if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
				_entity.addEffect(new MobEffectInstance(ZehirmoduforgeModMobEffects.ZEHIR_VAR.get(), 60, 1));
		}
		if (hasEntityInInventory(entity, new ItemStack(ZehirmoduforgeModBlocks.ZEHIRLI_TAS.get()))) {
			if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
				_entity.addEffect(new MobEffectInstance(ZehirmoduforgeModMobEffects.ZEHIR_VAR.get(), 60, 1));
		}
		if (hasEntityInInventory(entity, new ItemStack(ZehirmoduforgeModBlocks.KIRIKTAS.get()))) {
			if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
				_entity.addEffect(new MobEffectInstance(ZehirmoduforgeModMobEffects.ZEHIR_VAR.get(), 60, 1));
		}
		if (hasEntityInInventory(entity, new ItemStack(ZehirmoduforgeModBlocks.MESE_TAHTASI.get()))) {
			if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
				_entity.addEffect(new MobEffectInstance(ZehirmoduforgeModMobEffects.ZEHIR_VAR.get(), 60, 1));
		}
		if (hasEntityInInventory(entity, new ItemStack(ZehirmoduforgeModBlocks.MESE_KUTUGU.get()))) {
			if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
				_entity.addEffect(new MobEffectInstance(ZehirmoduforgeModMobEffects.ZEHIR_VAR.get(), 60, 1));
		}
		if (hasEntityInInventory(entity, new ItemStack(ZehirmoduforgeModBlocks.GLASS.get()))) {
			if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
				_entity.addEffect(new MobEffectInstance(ZehirmoduforgeModMobEffects.ZEHIR_VAR.get(), 60, 1));
		}
		if (hasEntityInInventory(entity, new ItemStack(ZehirmoduforgeModBlocks.LADIN_KUTUGU.get()))) {
			if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
				_entity.addEffect(new MobEffectInstance(ZehirmoduforgeModMobEffects.ZEHIR_VAR.get(), 60, 1));
		}
		if (hasEntityInInventory(entity, new ItemStack(ZehirmoduforgeModBlocks.LADIN_TAHTASI.get()))) {
			if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
				_entity.addEffect(new MobEffectInstance(ZehirmoduforgeModMobEffects.ZEHIR_VAR.get(), 60, 1));
		}
		if (hasEntityInInventory(entity, new ItemStack(ZehirmoduforgeModBlocks.HUS_KUTUGU.get()))) {
			if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
				_entity.addEffect(new MobEffectInstance(ZehirmoduforgeModMobEffects.ZEHIR_VAR.get(), 60, 1));
		}
		if (hasEntityInInventory(entity, new ItemStack(ZehirmoduforgeModBlocks.HUS_TAHTASI.get()))) {
			if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
				_entity.addEffect(new MobEffectInstance(ZehirmoduforgeModMobEffects.ZEHIR_VAR.get(), 60, 1));
		}
		if (hasEntityInInventory(entity, new ItemStack(ZehirmoduforgeModBlocks.ORMAN_AGACI_KUTUGU.get()))) {
			if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
				_entity.addEffect(new MobEffectInstance(ZehirmoduforgeModMobEffects.ZEHIR_VAR.get(), 60, 1));
		}
		if (hasEntityInInventory(entity, new ItemStack(ZehirmoduforgeModBlocks.ORMAN_AGACI_TAHTASI.get()))) {
			if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
				_entity.addEffect(new MobEffectInstance(ZehirmoduforgeModMobEffects.ZEHIR_VAR.get(), 60, 1));
		}
	}

	private static boolean hasEntityInInventory(Entity entity, ItemStack itemstack) {
		if (entity instanceof Player player) {
			Inventory inventory = player.getInventory();
			List<NonNullList<ItemStack>> compartments = com.google.common.collect.ImmutableList.of(inventory.items, inventory.armor, inventory.offhand);
			for (List<ItemStack> list : compartments) {
				for (ItemStack itemstack2 : list) {
					if (!itemstack2.isEmpty() && ItemStack.isSameItem(itemstack2, itemstack)) {
						return true;
					}
				}
			}
		}
		return false;
	}
}