/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.zehirmodu.init;

import net.minecraft.world.effect.MobEffect;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.Registry;
import net.minecraft.core.Holder;

import net.mcreator.zehirmodu.potion.ZehirVarMobEffect;
import net.mcreator.zehirmodu.ZehirModuMod;

import java.util.function.Supplier;

public class ZehirModuModMobEffects {
	public static Holder<MobEffect> ZEHIR_VAR;

	public static void load() {
		ZEHIR_VAR = register("zehir_var", ZehirVarMobEffect::new);
	}

	private static Holder<MobEffect> register(String registryname, Supplier<MobEffect> element) {
		return Holder.direct(Registry.register(BuiltInRegistries.MOB_EFFECT, ResourceLocation.fromNamespaceAndPath(ZehirModuMod.MODID, registryname), element.get()));
	}
}