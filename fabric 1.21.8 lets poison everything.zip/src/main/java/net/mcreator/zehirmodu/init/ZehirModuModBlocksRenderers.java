/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.zehirmodu.init;

import net.mcreator.zehirmodu.fluid.AsitFluid;

import net.fabricmc.api.Environment;
import net.fabricmc.api.EnvType;

@Environment(EnvType.CLIENT)
public class ZehirModuModBlocksRenderers {
	public static void clientLoad() {
		AsitFluid.registerRenderLayer();
	}
	// Start of user code block custom block renderers
	// End of user code block custom block renderers
}