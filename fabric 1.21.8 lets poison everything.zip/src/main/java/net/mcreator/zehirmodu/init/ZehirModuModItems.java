/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.zehirmodu.init;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.resources.ResourceKey;
import net.minecraft.core.registries.Registries;

import net.mcreator.zehirmodu.item.*;
import net.mcreator.zehirmodu.ZehirModuMod;

import java.util.function.Function;

public class ZehirModuModItems {
	public static Item EKMEK;
	public static Item ASIT_BUCKET;
	public static Item ZEHIRCEVHERI;
	public static Item ASIT_MADENI;
	public static Item ZEHIRLI_BIFTEK;
	public static Item PISMISKOYUNETI;
	public static Item PISMISTAVUKETI;
	public static Item PISMIS_TAVSANETI;
	public static Item PISMIS_MORINA;
	public static Item PISMIS_SOMON;
	public static Item PISMIS_PATATES;
	public static Item PISMIS_DOMUZ_PIRZOLASI;
	public static Item ALTIN_ELMA;
	public static Item NAKARAT_MEYVESI;
	public static Item SUT_KOVASI_ZEHIRLI;
	public static Item KURABIYE;
	public static Item BAL_SISESI;
	public static Item BAL_KABAGI_TURTASI;
	public static Item KURUTULMUS_SU_YOSUNU;
	public static Item MANTAR_GUVECI;
	public static Item PANCAR_CORBASI;
	public static Item TAVSAN_GUVECI;
	public static Item SUPHELI_GUVEC;
	public static Item ELMA;
	public static Item ZEHI_DEDEKTORU;
	public static Item TOPRAK;
	public static Item MESE_KUTUGU;
	public static Item MESE_TAHTASI;
	public static Item TAS;
	public static Item KIRIK_TAS;
	public static Item LADIN_KUTUGU;
	public static Item LADIN_TAHTASI;
	public static Item HUSKUTUGU;
	public static Item HUS_TAHTASI;
	public static Item ORMAN_AGACI_KUTUGU;
	public static Item ORMANAGACITAHTASI;
	public static Item AKASYA_KUTUGU;
	public static Item AKASYA_TAHTASI;
	public static Item KOYU_MESE_KUTUGU;
	public static Item KOYU_MESE_TAHTASI;
	public static Item MANGROV_KUTUGU;
	public static Item MANGROVTAHTASI;
	public static Item KIRAZ_AGACI_KUTUGU;
	public static Item KIRAZ_AGACI_TAHTA;
	public static Item PANZEHIR;

	public static void load() {
		EKMEK = register("ekmek", EkmekItem::new);
		ASIT_BUCKET = register("asit_bucket", AsitItem::new);
		ZEHIRCEVHERI = register("zehircevheri", ZehircevheriItem::new);
		ASIT_MADENI = block(ZehirModuModBlocks.ASIT_MADENI, "asit_madeni");
		ZEHIRLI_BIFTEK = register("zehirli_biftek", ZehirliBiftekItem::new);
		PISMISKOYUNETI = register("pismiskoyuneti", PismiskoyunetiItem::new);
		PISMISTAVUKETI = register("pismistavuketi", PismistavuketiItem::new);
		PISMIS_TAVSANETI = register("pismis_tavsaneti", PismisTavsanetiItem::new);
		PISMIS_MORINA = register("pismis_morina", PismisMorinaItem::new);
		PISMIS_SOMON = register("pismis_somon", PismisSomonItem::new);
		PISMIS_PATATES = register("pismis_patates", PismisPatatesItem::new);
		PISMIS_DOMUZ_PIRZOLASI = register("pismis_domuz_pirzolasi", PismisDomuzPirzolasiItem::new);
		ALTIN_ELMA = register("altin_elma", AltinElmaItem::new);
		NAKARAT_MEYVESI = register("nakarat_meyvesi", NakaratMeyvesiItem::new);
		SUT_KOVASI_ZEHIRLI = register("sut_kovasi_zehirli", SutKovasiZehirliItem::new);
		KURABIYE = register("kurabiye", KurabiyeItem::new);
		BAL_SISESI = register("bal_sisesi", BalSisesiItem::new);
		BAL_KABAGI_TURTASI = register("bal_kabagi_turtasi", BalKabagiTurtasiItem::new);
		KURUTULMUS_SU_YOSUNU = register("kurutulmus_su_yosunu", KurutulmusSuYosunuItem::new);
		MANTAR_GUVECI = register("mantar_guveci", MantarGuveciItem::new);
		PANCAR_CORBASI = register("pancar_corbasi", PancarCorbasiItem::new);
		TAVSAN_GUVECI = register("tavsan_guveci", TavsanGuveciItem::new);
		SUPHELI_GUVEC = register("supheli_guvec", SupheliGuvecItem::new);
		ELMA = register("elma", ElmaItem::new);
		ZEHI_DEDEKTORU = register("zehi_dedektoru", ZehiDedektoruItem::new);
		TOPRAK = block(ZehirModuModBlocks.TOPRAK, "toprak");
		MESE_KUTUGU = block(ZehirModuModBlocks.MESE_KUTUGU, "mese_kutugu");
		MESE_TAHTASI = block(ZehirModuModBlocks.MESE_TAHTASI, "mese_tahtasi");
		TAS = block(ZehirModuModBlocks.TAS, "tas");
		KIRIK_TAS = block(ZehirModuModBlocks.KIRIK_TAS, "kirik_tas");
		LADIN_KUTUGU = block(ZehirModuModBlocks.LADIN_KUTUGU, "ladin_kutugu");
		LADIN_TAHTASI = block(ZehirModuModBlocks.LADIN_TAHTASI, "ladin_tahtasi");
		HUSKUTUGU = block(ZehirModuModBlocks.HUSKUTUGU, "huskutugu");
		HUS_TAHTASI = block(ZehirModuModBlocks.HUS_TAHTASI, "hus_tahtasi");
		ORMAN_AGACI_KUTUGU = block(ZehirModuModBlocks.ORMAN_AGACI_KUTUGU, "orman_agaci_kutugu");
		ORMANAGACITAHTASI = block(ZehirModuModBlocks.ORMANAGACITAHTASI, "ormanagacitahtasi");
		AKASYA_KUTUGU = block(ZehirModuModBlocks.AKASYA_KUTUGU, "akasya_kutugu");
		AKASYA_TAHTASI = block(ZehirModuModBlocks.AKASYA_TAHTASI, "akasya_tahtasi");
		KOYU_MESE_KUTUGU = block(ZehirModuModBlocks.KOYU_MESE_KUTUGU, "koyu_mese_kutugu");
		KOYU_MESE_TAHTASI = block(ZehirModuModBlocks.KOYU_MESE_TAHTASI, "koyu_mese_tahtasi");
		MANGROV_KUTUGU = block(ZehirModuModBlocks.MANGROV_KUTUGU, "mangrov_kutugu");
		MANGROVTAHTASI = block(ZehirModuModBlocks.MANGROVTAHTASI, "mangrovtahtasi");
		KIRAZ_AGACI_KUTUGU = block(ZehirModuModBlocks.KIRAZ_AGACI_KUTUGU, "kiraz_agaci_kutugu");
		KIRAZ_AGACI_TAHTA = block(ZehirModuModBlocks.KIRAZ_AGACI_TAHTA, "kiraz_agaci_tahta");
		PANZEHIR = register("panzehir", PanzehirItem::new);
	}

	// Start of user code block custom items
	// End of user code block custom items
	private static <I extends Item> I register(String name, Function<Item.Properties, ? extends I> supplier) {
		return (I) Items.registerItem(ResourceKey.create(Registries.ITEM, ResourceLocation.fromNamespaceAndPath(ZehirModuMod.MODID, name)), (Function<Item.Properties, Item>) supplier);
	}

	private static Item block(Block block, String name) {
		return block(block, name, new Item.Properties());
	}

	private static Item block(Block block, String name, Item.Properties properties) {
		return Items.registerItem(ResourceKey.create(Registries.ITEM, ResourceLocation.fromNamespaceAndPath(ZehirModuMod.MODID, name)), prop -> new BlockItem(block, prop), properties);
	}
}