/*
 * MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.zehirmodu.init;

import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.material.FlowingFluid;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.Registry;

import net.mcreator.zehirmodu.fluid.AsitFluid;
import net.mcreator.zehirmodu.ZehirModuMod;

import net.fabricmc.api.Environment;
import net.fabricmc.api.EnvType;

import java.util.function.Supplier;

public class ZehirModuModFluids {
	public static FlowingFluid ASIT;
	public static FlowingFluid FLOWING_ASIT;

	public static void load() {
		ASIT = register("asit", AsitFluid.Source::new);
		FLOWING_ASIT = register("flowing_asit", AsitFluid.Flowing::new);
	}

	@Environment(EnvType.CLIENT)
	public static void clientLoad() {
		AsitFluid.clientLoad();
	}

	private static <F extends Fluid> F register(String registryname, Supplier<F> element) {
		return (F) Registry.register(BuiltInRegistries.FLUID, ResourceLocation.fromNamespaceAndPath(ZehirModuMod.MODID, registryname), element.get());
	}
}