/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.zehirmodu.init;

import net.minecraft.world.item.CreativeModeTabs;

import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;

public class ZehirModuModTabs {
	public static void load() {
		ItemGroupEvents.modifyEntriesEvent(CreativeModeTabs.FOOD_AND_DRINKS).register(tabData -> {
			tabData.accept(ZehirModuModItems.EKMEK);
			tabData.accept(ZehirModuModItems.ASIT_BUCKET);
			tabData.accept(ZehirModuModItems.ZEHIRLI_BIFTEK);
			tabData.accept(ZehirModuModItems.PISMISKOYUNETI);
			tabData.accept(ZehirModuModItems.PISMISTAVUKETI);
			tabData.accept(ZehirModuModItems.PISMIS_TAVSANETI);
			tabData.accept(ZehirModuModItems.PISMIS_MORINA);
			tabData.accept(ZehirModuModItems.PISMIS_SOMON);
			tabData.accept(ZehirModuModItems.PISMIS_PATATES);
			tabData.accept(ZehirModuModItems.PISMIS_DOMUZ_PIRZOLASI);
			tabData.accept(ZehirModuModItems.ALTIN_ELMA);
			tabData.accept(ZehirModuModItems.NAKARAT_MEYVESI);
			tabData.accept(ZehirModuModItems.SUT_KOVASI_ZEHIRLI);
			tabData.accept(ZehirModuModItems.KURABIYE);
			tabData.accept(ZehirModuModItems.BAL_SISESI);
			tabData.accept(ZehirModuModItems.BAL_KABAGI_TURTASI);
			tabData.accept(ZehirModuModItems.KURUTULMUS_SU_YOSUNU);
			tabData.accept(ZehirModuModItems.MANTAR_GUVECI);
			tabData.accept(ZehirModuModItems.PANCAR_CORBASI);
			tabData.accept(ZehirModuModItems.TAVSAN_GUVECI);
			tabData.accept(ZehirModuModItems.SUPHELI_GUVEC);
			tabData.accept(ZehirModuModItems.ELMA);
			tabData.accept(ZehirModuModItems.PANZEHIR);
		});
		ItemGroupEvents.modifyEntriesEvent(CreativeModeTabs.INGREDIENTS).register(tabData -> {
			tabData.accept(ZehirModuModItems.ZEHIRCEVHERI);
			tabData.accept(ZehirModuModBlocks.ASIT_MADENI.asItem());
		});
		ItemGroupEvents.modifyEntriesEvent(CreativeModeTabs.REDSTONE_BLOCKS).register(tabData -> {
			tabData.accept(ZehirModuModItems.ZEHI_DEDEKTORU);
		});
		ItemGroupEvents.modifyEntriesEvent(CreativeModeTabs.BUILDING_BLOCKS).register(tabData -> {
			tabData.accept(ZehirModuModBlocks.MESE_KUTUGU.asItem());
			tabData.accept(ZehirModuModBlocks.MESE_TAHTASI.asItem());
			tabData.accept(ZehirModuModBlocks.KIRIK_TAS.asItem());
			tabData.accept(ZehirModuModBlocks.LADIN_KUTUGU.asItem());
			tabData.accept(ZehirModuModBlocks.LADIN_TAHTASI.asItem());
			tabData.accept(ZehirModuModBlocks.HUSKUTUGU.asItem());
			tabData.accept(ZehirModuModBlocks.HUS_TAHTASI.asItem());
			tabData.accept(ZehirModuModBlocks.ORMAN_AGACI_KUTUGU.asItem());
			tabData.accept(ZehirModuModBlocks.ORMANAGACITAHTASI.asItem());
			tabData.accept(ZehirModuModBlocks.AKASYA_KUTUGU.asItem());
			tabData.accept(ZehirModuModBlocks.AKASYA_TAHTASI.asItem());
			tabData.accept(ZehirModuModBlocks.KOYU_MESE_KUTUGU.asItem());
			tabData.accept(ZehirModuModBlocks.KOYU_MESE_TAHTASI.asItem());
			tabData.accept(ZehirModuModBlocks.MANGROV_KUTUGU.asItem());
			tabData.accept(ZehirModuModBlocks.MANGROVTAHTASI.asItem());
			tabData.accept(ZehirModuModBlocks.KIRAZ_AGACI_KUTUGU.asItem());
			tabData.accept(ZehirModuModBlocks.KIRAZ_AGACI_TAHTA.asItem());
		});
		ItemGroupEvents.modifyEntriesEvent(CreativeModeTabs.NATURAL_BLOCKS).register(tabData -> {
			tabData.accept(ZehirModuModBlocks.TAS.asItem());
		});
	}
}