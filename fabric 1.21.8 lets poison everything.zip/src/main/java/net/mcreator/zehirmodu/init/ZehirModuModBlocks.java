/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.zehirmodu.init;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.Block;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.resources.ResourceKey;
import net.minecraft.core.registries.Registries;

import net.mcreator.zehirmodu.block.*;
import net.mcreator.zehirmodu.ZehirModuMod;

import java.util.function.Function;

public class ZehirModuModBlocks {
	public static Block ASIT;
	public static Block ASIT_MADENI;
	public static Block TOPRAK;
	public static Block MESE_KUTUGU;
	public static Block MESE_TAHTASI;
	public static Block TAS;
	public static Block KIRIK_TAS;
	public static Block LADIN_KUTUGU;
	public static Block LADIN_TAHTASI;
	public static Block HUSKUTUGU;
	public static Block HUS_TAHTASI;
	public static Block ORMAN_AGACI_KUTUGU;
	public static Block ORMANAGACITAHTASI;
	public static Block AKASYA_KUTUGU;
	public static Block AKASYA_TAHTASI;
	public static Block KOYU_MESE_KUTUGU;
	public static Block KOYU_MESE_TAHTASI;
	public static Block MANGROV_KUTUGU;
	public static Block MANGROVTAHTASI;
	public static Block KIRAZ_AGACI_KUTUGU;
	public static Block KIRAZ_AGACI_TAHTA;

	public static void load() {
		ASIT = register("asit", AsitBlock::new);
		ASIT_MADENI = register("asit_madeni", AsitMadeniBlock::new);
		TOPRAK = register("toprak", ToprakBlock::new);
		MESE_KUTUGU = register("mese_kutugu", MeseKutuguBlock::new);
		MESE_TAHTASI = register("mese_tahtasi", MeseTahtasiBlock::new);
		TAS = register("tas", TasBlock::new);
		KIRIK_TAS = register("kirik_tas", KirikTasBlock::new);
		LADIN_KUTUGU = register("ladin_kutugu", LadinKutuguBlock::new);
		LADIN_TAHTASI = register("ladin_tahtasi", LadinTahtasiBlock::new);
		HUSKUTUGU = register("huskutugu", HuskutuguBlock::new);
		HUS_TAHTASI = register("hus_tahtasi", HusTahtasiBlock::new);
		ORMAN_AGACI_KUTUGU = register("orman_agaci_kutugu", OrmanAgaciKutuguBlock::new);
		ORMANAGACITAHTASI = register("ormanagacitahtasi", OrmanagacitahtasiBlock::new);
		AKASYA_KUTUGU = register("akasya_kutugu", AkasyaKutuguBlock::new);
		AKASYA_TAHTASI = register("akasya_tahtasi", AkasyaTahtasiBlock::new);
		KOYU_MESE_KUTUGU = register("koyu_mese_kutugu", KoyuMeseKutuguBlock::new);
		KOYU_MESE_TAHTASI = register("koyu_mese_tahtasi", KoyuMeseTahtasiBlock::new);
		MANGROV_KUTUGU = register("mangrov_kutugu", MangrovKutuguBlock::new);
		MANGROVTAHTASI = register("mangrovtahtasi", MangrovtahtasiBlock::new);
		KIRAZ_AGACI_KUTUGU = register("kiraz_agaci_kutugu", KirazAgaciKutuguBlock::new);
		KIRAZ_AGACI_TAHTA = register("kiraz_agaci_tahta", KirazAgaciTahtaBlock::new);
	}

	// Start of user code block custom blocks
	// End of user code block custom blocks
	private static <B extends Block> B register(String name, Function<BlockBehaviour.Properties, B> supplier) {
		return (B) Blocks.register(ResourceKey.create(Registries.BLOCK, ResourceLocation.fromNamespaceAndPath(ZehirModuMod.MODID, name)), (Function<BlockBehaviour.Properties, Block>) supplier, BlockBehaviour.Properties.of());
	}
}