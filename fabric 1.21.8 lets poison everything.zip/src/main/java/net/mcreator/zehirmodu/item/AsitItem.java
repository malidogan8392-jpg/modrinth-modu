package net.mcreator.zehirmodu.item;

import net.minecraft.world.item.Items;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BucketItem;

import net.mcreator.zehirmodu.init.ZehirModuModFluids;

public class AsitItem extends BucketItem {
	public AsitItem(Item.Properties properties) {
		super(ZehirModuModFluids.ASIT, properties.craftRemainder(Items.BUCKET).stacksTo(1)

		);
	}
}