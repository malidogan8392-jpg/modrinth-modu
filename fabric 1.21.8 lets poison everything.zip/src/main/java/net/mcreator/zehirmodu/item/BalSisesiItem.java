package net.mcreator.zehirmodu.item;

import net.minecraft.world.item.component.Consumables;
import net.minecraft.world.item.Item;
import net.minecraft.world.food.FoodProperties;

public class BalSisesiItem extends Item {
	public BalSisesiItem(Item.Properties properties) {
		super(properties.stacksTo(1).food((new FoodProperties.Builder()).nutrition(4).saturationModifier(0.3f).build(), Consumables.DEFAULT_DRINK));
	}
}