package net.mcreator.zehirmodu.item;

import net.minecraft.world.item.Item;

public class ZehircevheriItem extends Item {
	public ZehircevheriItem(Item.Properties properties) {
		super(properties);
	}
}