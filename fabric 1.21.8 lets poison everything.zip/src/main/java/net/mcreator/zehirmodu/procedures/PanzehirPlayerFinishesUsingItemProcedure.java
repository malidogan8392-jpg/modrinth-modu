package net.mcreator.zehirmodu.procedures;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.effect.MobEffectInstance;

public class PanzehirPlayerFinishesUsingItemProcedure {
	public static boolean eventResult = true;

	public static void execute(Entity entity) {
		if (entity == null)
			return;
		if (entity instanceof LivingEntity _entity) {
			_entity.removeEffect(MobEffects.WITHER);
			_entity.removeEffect(MobEffects.POISON);
			_entity.removeEffect(MobEffects.SLOWNESS);
			_entity.removeEffect(MobEffects.BLINDNESS);
			_entity.removeEffect(MobEffects.DARKNESS);
			_entity.removeEffect(MobEffects.HUNGER);
			_entity.removeEffect(MobEffects.INFESTED);
			_entity.removeEffect(MobEffects.MINING_FATIGUE);
			_entity.removeEffect(MobEffects.NAUSEA);
			_entity.removeEffect(MobEffects.OOZING);
			_entity.removeEffect(MobEffects.RAID_OMEN);
			_entity.removeEffect(MobEffects.UNLUCK);
			_entity.removeEffect(MobEffects.WEAKNESS);
			_entity.removeEffect(MobEffects.WITHER);
		}
		if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide()) {
			_entity.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 1200, 1));
		}
	}
}