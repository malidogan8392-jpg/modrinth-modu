package net.mcreator.zehirmodu.procedures;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.effect.MobEffectInstance;

public class AsitMobplayerCollidesBlockProcedure {
	public static boolean eventResult = true;

	public static void execute(Entity entity) {
		if (entity == null)
			return;
		if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide()) {
			_entity.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, 20, 1));
			_entity.addEffect(new MobEffectInstance(MobEffects.DARKNESS, 20, 1));
			_entity.addEffect(new MobEffectInstance(MobEffects.WITHER, 20, 1));
			_entity.addEffect(new MobEffectInstance(MobEffects.POISON, 20, 1));
		}
	}
}