package net.mcreator.zehirmodu.procedures;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.effect.MobEffectInstance;

import net.mcreator.zehirmodu.init.ZehirModuModMobEffects;
import net.mcreator.zehirmodu.init.ZehirModuModItems;
import net.mcreator.zehirmodu.init.ZehirModuModBlocks;

public class ZehiDedektoruItemInHandTickProcedure {
	public static boolean eventResult = true;

	public static void execute(Entity entity) {
		if (entity == null)
			return;
		if (hasEntityInInventory(entity, new ItemStack(ZehirModuModItems.EKMEK))) {
			if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide()) {
				_entity.addEffect(new MobEffectInstance(ZehirModuModMobEffects.ZEHIR_VAR, 60, 1));
			}
		}
		if (hasEntityInInventory(entity, new ItemStack(ZehirModuModItems.ZEHIRLI_BIFTEK))) {
			if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide()) {
				_entity.addEffect(new MobEffectInstance(ZehirModuModMobEffects.ZEHIR_VAR, 60, 1));
			}
		}
		if (hasEntityInInventory(entity, new ItemStack(ZehirModuModItems.PISMISKOYUNETI))) {
			if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide()) {
				_entity.addEffect(new MobEffectInstance(ZehirModuModMobEffects.ZEHIR_VAR, 60, 1));
			}
		}
		if (hasEntityInInventory(entity, new ItemStack(ZehirModuModItems.PISMISTAVUKETI))) {
			if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide()) {
				_entity.addEffect(new MobEffectInstance(ZehirModuModMobEffects.ZEHIR_VAR, 60, 1));
			}
		}
		if (hasEntityInInventory(entity, new ItemStack(ZehirModuModItems.PISMIS_TAVSANETI))) {
			if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide()) {
				_entity.addEffect(new MobEffectInstance(ZehirModuModMobEffects.ZEHIR_VAR, 60, 1));
			}
		}
		if (hasEntityInInventory(entity, new ItemStack(ZehirModuModItems.PISMIS_MORINA))) {
			if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide()) {
				_entity.addEffect(new MobEffectInstance(ZehirModuModMobEffects.ZEHIR_VAR, 60, 1));
			}
		}
		if (hasEntityInInventory(entity, new ItemStack(ZehirModuModItems.PISMIS_SOMON))) {
			if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide()) {
				_entity.addEffect(new MobEffectInstance(ZehirModuModMobEffects.ZEHIR_VAR, 60, 1));
			}
		}
		if (hasEntityInInventory(entity, new ItemStack(ZehirModuModItems.PISMIS_PATATES))) {
			if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide()) {
				_entity.addEffect(new MobEffectInstance(ZehirModuModMobEffects.ZEHIR_VAR, 60, 1));
			}
		}
		if (hasEntityInInventory(entity, new ItemStack(ZehirModuModItems.PISMIS_DOMUZ_PIRZOLASI))) {
			if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide()) {
				_entity.addEffect(new MobEffectInstance(ZehirModuModMobEffects.ZEHIR_VAR, 60, 1));
			}
		}
		if (hasEntityInInventory(entity, new ItemStack(ZehirModuModItems.ALTIN_ELMA))) {
			if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide()) {
				_entity.addEffect(new MobEffectInstance(ZehirModuModMobEffects.ZEHIR_VAR, 60, 1));
			}
		}
		if (hasEntityInInventory(entity, new ItemStack(ZehirModuModItems.NAKARAT_MEYVESI))) {
			if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide()) {
				_entity.addEffect(new MobEffectInstance(ZehirModuModMobEffects.ZEHIR_VAR, 60, 1));
			}
		}
		if (hasEntityInInventory(entity, new ItemStack(ZehirModuModItems.SUT_KOVASI_ZEHIRLI))) {
			if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide()) {
				_entity.addEffect(new MobEffectInstance(ZehirModuModMobEffects.ZEHIR_VAR, 60, 1));
			}
		}
		if (hasEntityInInventory(entity, new ItemStack(ZehirModuModItems.KURABIYE))) {
			if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide()) {
				_entity.addEffect(new MobEffectInstance(ZehirModuModMobEffects.ZEHIR_VAR, 60, 1));
			}
		}
		if (hasEntityInInventory(entity, new ItemStack(ZehirModuModItems.BAL_SISESI))) {
			if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide()) {
				_entity.addEffect(new MobEffectInstance(ZehirModuModMobEffects.ZEHIR_VAR, 60, 1));
			}
		}
		if (hasEntityInInventory(entity, new ItemStack(ZehirModuModItems.BAL_KABAGI_TURTASI))) {
			if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide()) {
				_entity.addEffect(new MobEffectInstance(ZehirModuModMobEffects.ZEHIR_VAR, 60, 1));
			}
		}
		if (hasEntityInInventory(entity, new ItemStack(ZehirModuModItems.KURUTULMUS_SU_YOSUNU))) {
			if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide()) {
				_entity.addEffect(new MobEffectInstance(ZehirModuModMobEffects.ZEHIR_VAR, 60, 1));
			}
		}
		if (hasEntityInInventory(entity, new ItemStack(ZehirModuModItems.MANTAR_GUVECI))) {
			if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide()) {
				_entity.addEffect(new MobEffectInstance(ZehirModuModMobEffects.ZEHIR_VAR, 60, 1));
			}
		}
		if (hasEntityInInventory(entity, new ItemStack(ZehirModuModItems.PANCAR_CORBASI))) {
			if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide()) {
				_entity.addEffect(new MobEffectInstance(ZehirModuModMobEffects.ZEHIR_VAR, 60, 1));
			}
		}
		if (hasEntityInInventory(entity, new ItemStack(ZehirModuModItems.TAVSAN_GUVECI))) {
			if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide()) {
				_entity.addEffect(new MobEffectInstance(ZehirModuModMobEffects.ZEHIR_VAR, 60, 1));
			}
		}
		if (hasEntityInInventory(entity, new ItemStack(ZehirModuModItems.SUPHELI_GUVEC))) {
			if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide()) {
				_entity.addEffect(new MobEffectInstance(ZehirModuModMobEffects.ZEHIR_VAR, 60, 1));
			}
		}
		if (hasEntityInInventory(entity, new ItemStack(ZehirModuModItems.ELMA))) {
			if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide()) {
				_entity.addEffect(new MobEffectInstance(ZehirModuModMobEffects.ZEHIR_VAR, 60, 1));
			}
		}
		if (hasEntityInInventory(entity, new ItemStack(ZehirModuModBlocks.TOPRAK))) {
			if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide()) {
				_entity.addEffect(new MobEffectInstance(ZehirModuModMobEffects.ZEHIR_VAR, 60, 1));
			}
		}
		if (hasEntityInInventory(entity, new ItemStack(ZehirModuModBlocks.MESE_KUTUGU))) {
			if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide()) {
				_entity.addEffect(new MobEffectInstance(ZehirModuModMobEffects.ZEHIR_VAR, 60, 1));
			}
		}
		if (hasEntityInInventory(entity, new ItemStack(ZehirModuModBlocks.MESE_TAHTASI))) {
			if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide()) {
				_entity.addEffect(new MobEffectInstance(ZehirModuModMobEffects.ZEHIR_VAR, 60, 1));
			}
		}
		if (hasEntityInInventory(entity, new ItemStack(ZehirModuModBlocks.TAS))) {
			if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide()) {
				_entity.addEffect(new MobEffectInstance(ZehirModuModMobEffects.ZEHIR_VAR, 60, 1));
			}
		}
		if (hasEntityInInventory(entity, new ItemStack(ZehirModuModBlocks.KIRIK_TAS))) {
			if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide()) {
				_entity.addEffect(new MobEffectInstance(ZehirModuModMobEffects.ZEHIR_VAR, 60, 1));
			}
		}
		if (hasEntityInInventory(entity, new ItemStack(ZehirModuModBlocks.LADIN_KUTUGU))) {
			if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide()) {
				_entity.addEffect(new MobEffectInstance(ZehirModuModMobEffects.ZEHIR_VAR, 60, 1));
			}
		}
		if (hasEntityInInventory(entity, new ItemStack(ZehirModuModBlocks.LADIN_TAHTASI))) {
			if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide()) {
				_entity.addEffect(new MobEffectInstance(ZehirModuModMobEffects.ZEHIR_VAR, 60, 1));
			}
		}
		if (hasEntityInInventory(entity, new ItemStack(ZehirModuModBlocks.HUSKUTUGU))) {
			if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide()) {
				_entity.addEffect(new MobEffectInstance(ZehirModuModMobEffects.ZEHIR_VAR, 60, 1));
			}
		}
		if (hasEntityInInventory(entity, new ItemStack(ZehirModuModBlocks.HUS_TAHTASI))) {
			if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide()) {
				_entity.addEffect(new MobEffectInstance(ZehirModuModMobEffects.ZEHIR_VAR, 60, 1));
			}
		}
		if (hasEntityInInventory(entity, new ItemStack(ZehirModuModBlocks.ORMAN_AGACI_KUTUGU))) {
			if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide()) {
				_entity.addEffect(new MobEffectInstance(ZehirModuModMobEffects.ZEHIR_VAR, 60, 1));
			}
		}
		if (hasEntityInInventory(entity, new ItemStack(ZehirModuModBlocks.ORMANAGACITAHTASI))) {
			if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide()) {
				_entity.addEffect(new MobEffectInstance(ZehirModuModMobEffects.ZEHIR_VAR, 60, 1));
			}
		}
		if (hasEntityInInventory(entity, new ItemStack(ZehirModuModBlocks.AKASYA_KUTUGU))) {
			if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide()) {
				_entity.addEffect(new MobEffectInstance(ZehirModuModMobEffects.ZEHIR_VAR, 60, 1));
			}
		}
		if (hasEntityInInventory(entity, new ItemStack(ZehirModuModBlocks.AKASYA_TAHTASI))) {
			if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide()) {
				_entity.addEffect(new MobEffectInstance(ZehirModuModMobEffects.ZEHIR_VAR, 60, 1));
			}
		}
		if (hasEntityInInventory(entity, new ItemStack(ZehirModuModBlocks.KOYU_MESE_KUTUGU))) {
			if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide()) {
				_entity.addEffect(new MobEffectInstance(ZehirModuModMobEffects.ZEHIR_VAR, 60, 1));
			}
		}
		if (hasEntityInInventory(entity, new ItemStack(ZehirModuModBlocks.KOYU_MESE_TAHTASI))) {
			if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide()) {
				_entity.addEffect(new MobEffectInstance(ZehirModuModMobEffects.ZEHIR_VAR, 60, 1));
			}
		}
		if (hasEntityInInventory(entity, new ItemStack(ZehirModuModBlocks.MANGROV_KUTUGU))) {
			if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide()) {
				_entity.addEffect(new MobEffectInstance(ZehirModuModMobEffects.ZEHIR_VAR, 60, 1));
			}
		}
		if (hasEntityInInventory(entity, new ItemStack(ZehirModuModBlocks.MANGROVTAHTASI))) {
			if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide()) {
				_entity.addEffect(new MobEffectInstance(ZehirModuModMobEffects.ZEHIR_VAR, 60, 1));
			}
		}
		if (hasEntityInInventory(entity, new ItemStack(ZehirModuModBlocks.KIRAZ_AGACI_KUTUGU))) {
			if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide()) {
				_entity.addEffect(new MobEffectInstance(ZehirModuModMobEffects.ZEHIR_VAR, 60, 1));
			}
		}
		if (hasEntityInInventory(entity, new ItemStack(ZehirModuModBlocks.KIRAZ_AGACI_TAHTA))) {
			if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide()) {
				_entity.addEffect(new MobEffectInstance(ZehirModuModMobEffects.ZEHIR_VAR, 60, 1));
			}
		}
	}

	private static boolean hasEntityInInventory(Entity entity, ItemStack itemstack) {
		if (entity instanceof Player player)
			return player.getInventory().contains(stack -> !stack.isEmpty() && ItemStack.isSameItem(stack, itemstack));
		return false;
	}
}