package net.mcreator.zehirmodu;

import net.mcreator.zehirmodu.init.ZehirModuModFluids;
import net.mcreator.zehirmodu.init.ZehirModuModEntityRenderers;
import net.mcreator.zehirmodu.init.ZehirModuModBlocksRenderers;

import net.fabricmc.api.Environment;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.ClientModInitializer;

@Environment(EnvType.CLIENT)
public class ZehirModuModClient implements ClientModInitializer {
	@Override
	public void onInitializeClient() {
		// Start of user code block mod constructor
		// End of user code block mod constructor
		ZehirModuModBlocksRenderers.clientLoad();
		ZehirModuModEntityRenderers.clientLoad();
		ZehirModuModFluids.clientLoad();
		// Start of user code block mod init
		// End of user code block mod init
	}
	// Start of user code block mod methods
	// End of user code block mod methods
}