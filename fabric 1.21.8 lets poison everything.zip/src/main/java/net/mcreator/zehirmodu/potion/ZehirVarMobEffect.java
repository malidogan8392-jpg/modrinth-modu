package net.mcreator.zehirmodu.potion;

import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffect;

public class ZehirVarMobEffect extends MobEffect {
	public ZehirVarMobEffect() {
		super(MobEffectCategory.NEUTRAL, -6750208);
	}
}